function KanbasNavigation() {
    return `
  <ul>
    <li><a href="/Kanbas/Account/Profile/screen.html">Account</a></li>
    <li><a href="/Kanbas/Dashboard/screen.html">Dashboard</a></li>
    <li><a href="/Kanbas/Courses/Home/screen.html">Courses</a></li>
  </ul>
  `;
}

export default KanbasNavigation;