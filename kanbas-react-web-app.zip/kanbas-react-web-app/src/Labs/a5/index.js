function Assignment5() {
  return (
    <div>
      <h1>Assignment 5</h1>
    </div>
  );
}

export default Assignment5;
