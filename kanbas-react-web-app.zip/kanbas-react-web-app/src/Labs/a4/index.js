function Assignment4() {
  return (
    <div>
      <h1>Assignment 4</h1>
    </div>
  );
}

export default Assignment4;
